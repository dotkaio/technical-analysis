# shasum 256 746b4dc035ebd981c3139890bf3d151f49c836948d35f570808139aa2c66a759

import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

class Get(object):
    """ Main """

    def __init__(self):
        #
        # That's all we need for request stock prices from the alphavantage API.
        # If you're interested in your own key or check the API documentation:
        #                                                         |
        #       https://www.alphavantage.co/support/#api-key  <---|
        #                                                         |
        #       https://www.alphavantage.co/documentation  <------'
        #
        self.url = "http://www.alphavantage.co/query"
        self.key = "8SNLOC3ASFQNRMMH"


    def intraday(self, symbol, interval="5min"):
        #
        # This function returns the latests 100 tick prices on the
        # 5 minutes time frame candle.
        # By default, the output is json and then is converted to
        # pandas using the method 'DataFrame().T' for further analysis.
        #
        # The only parameter requeried is the symbol. If you're
        # interested in differents data with different time_frame
        # or interval, just pass the specifications through tha call
        # with the same order as bellow in "payload". For instance:
        #
        #   import alpha
        #   get = alpha.Get()
        #   get.intraday('tsla', interval='1min',)
        #
        # Note - Beacause the simple scope of this applications that
        # is check for crosses between *Adjusted Close and *EMA9 of
        # a given Symbol(s), we'll be using only the '4. close' column
        # for comparison with EMA 9.
        #
        #   The output might look like this...
        #
        #                           1. open   2. high    3. low  4. close 5. volume
        #     2020-11-25 20:00:00  574.4000  575.0000  574.2000  575.0000     27605
        #     2020-11-25 19:55:00  575.1200  575.2900  574.3200  574.6000     17933
        #     2020-11-25 19:50:00  575.4000  575.5000  575.1000  575.1500      7689
        #     2020-11-25 19:45:00  575.1600  575.5100  574.8400  575.5000     11197
        #     2020-11-25 19:40:00  574.6000  575.2500  574.5600  575.1000      5414
        #     ...                       ...       ...       ...       ...       ...
        #     2020-11-25 12:05:00  562.5900  563.8990  562.0000  563.3410    383466
        #     2020-11-25 12:00:00  563.5300  563.8585  562.5000  562.5400    264246
        #     2020-11-25 11:55:00  562.0118  565.0900  561.9700  563.3600    502473
        #     2020-11-25 11:50:00  562.8000  563.7500  562.0000  562.2400    357094
        #     2020-11-25 11:45:00  564.2800  564.5000  561.6600  562.7000    567235
        #
        #     [100 rows x 5 columns]
        #
        payload = {
            "function" :    "TIME_SERIES_INTRADAY",
            "symbol" :      symbol,
            "interval":     interval,
            "apikey":       self.key }

        intraday_data = requests.get(self.url,params=payload).json()[f"Time Series ({interval})"]
        intraday_frame = pd.DataFrame(intraday_data).T
        return intraday_frame


    def ema(self, symbol, interval="daily", time_period=9, series_type="close"):
        #
        # The same as above, thought it returns 2000+ data points from the API
        # The only parameter requeried is the symbol.
        # If you want to fetch data with different time_frame
        # or interval, just pass the specifications through tha call
        # with the same order as bellow in "payload"
        #
        #   output...
        #
        #                      EMA
        #     2020-11-25  503.4013
        #     2020-11-24  485.7516
        #     2020-11-23  468.3445
        #     2020-11-20  454.9682
        #     2020-11-19  446.3077
        #     ...              ...
        #     2010-07-16    3.9134
        #     2010-07-15    3.8598
        #     2010-07-14    3.8303
        #     2010-07-13    3.7958
        #     2010-07-12    3.8378
        #
        #     [2615 rows x 1 columns]
        #
        payload = {
            "function":     "EMA",
            "symbol":       symbol,
            "interval":     interval,
            "time_period":  time_period,
            "series_type":  series_type,
            "apikey":       self.key }

        ema_data = requests.get(self.url,params=payload).json()["Technical Analysis: EMA"]
        ema_frame = pd.DataFrame(ema_data).T
        return ema_frame


    def cross(self, symbol):
        #
        # This guy is responsible for fetching the data and grep only
        # last two values of each function: intraday() and ema().
        #
        # after so, it assign a variable for each value, one and constantly check if they
        # had being crossed recently, for instance if intraday(575.0000) < ema(503.4013)...
        #
        get = Get()

        tick_data = get.intraday(symbol)
        tick_last_value = tick_data['4. close'][0]

        ema_data = get.ema(symbol)
        ema_last_value = pd.DataFrame(np.array(ema_data.head(1)))[0][0]

        return tick_last_value, ema_last_value


    def check_cross(self):
        tick_last_value
        ema_last_value
