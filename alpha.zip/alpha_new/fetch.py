import requests
import json

class Fetch(object):

    def __init__(self):

        self.url = "http://www.alphavantage.co/query"
        self.key = "8SNLOC3ASFQNRMMH"

    def intraday(self, symbol, interval="5min"):

        payload = {
            "function" :    "TIME_SERIES_INTRADAY",
            "symbol" :      symbol,
            "interval":     interval,
            "apikey":       self.key
        }
        r = requests.get(self.url, params=payload)
        return r.json()[f"Time Series ({interval})"]

    def ema(self, symbol, interval="daily", time_period=9, series_type="close"):

        payload = {
            "function":     "EMA",
            "symbol":       symbol,
            "interval":     interval,
            "time_period":  time_period,
            "series_type":  series_type,
            "apikey":       self.key
        }
        r = requests.get(self.url, params=payload)
        return r.json()["Technical Analysis: EMA"]

    def cross(self, symbol):

        get = Fetch()

        tick_stamp = []
        tick_data = get.intraday(symbol)
        for stamp in tick_data:
            tick_stamp.append(stamp)

        ema_stamp = []
        ema_data = get.ema(symbol)
        for stamp in ema_data:
            ema_stamp.append(stamp)

        return tick_data[tick_stamp[0]]['4. close'], ema_data[ema_stamp[0]]['EMA']
